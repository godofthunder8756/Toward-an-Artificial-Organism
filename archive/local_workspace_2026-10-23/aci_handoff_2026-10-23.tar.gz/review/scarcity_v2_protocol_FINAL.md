# scarcity_v2 protocol FINAL: draft v4 plus Astra Consult #10 named edits ("FREEZE WITH NAMED EDITS")

**Status: FINAL TEXT FOR HASHING. NOT RUN.** The drafter did not freeze it. Freezing is the Specialist's step.
This file is `scarcity_v2_protocol_draft_v4.md` (md5 28c01ba1…, left untouched) plus only the Consult #10 edits
and flag rulings listed in §0.0. Drafts v1–v4 are untouched.

| Item | Value |
| --- | --- |
| Layer | C3 only: retention, access, routing, upkeep allocation |
| Supersedes | `scarcity_v2_protocol_draft_v3.md` (left untouched, md5 fcb2f362…). Drafts v1 (md5 13bb7b22…) and v2 (md5 45ac7705…) are also untouched. |
| Written | 2026-10-20 (EDT) by Research Delegate for the ACI Research Specialist, on behalf of Aidan Ahern |
| Sources | `/workspace/astra_consult_5_raw.md`, "CONSULT #8 RESPONSE"; the Specialist's instructions of 4:46 PM ET. v3 text is retained wherever Consult #8 did not require a change. |
| Repo | `/workspace/repo` untouched |

**Execution.** No search, solver or enumeration was executed. Every number is a hand derivation with its
arithmetic shown. The v3 closed forms in §5 were rechecked with exact rational arithmetic (`fractions.Fraction`,
about ten lines, no optimization). The v1-replay access values cited in §7.3 were **read** from the existing
`replay_results.json`; nothing was re-run.

**Scaffolding.** No protected controller or register is introduced. Ruling (1) explicitly keeps the history
register charged (§4.3, §15 F2).

**Claim discipline.** No consciousness claim. Q-EXIST, Q-LEARN, Q-CAUSE and Q-NECESSITY are kept separate.
ORIGIN is **untested** throughout. An optimal codebook is not acquired organization.

---

## 0.0 Edits applied (Astra Consult #10: FREEZE WITH NAMED EDITS)

Source: `/workspace/astra_consult10_response.txt`.

| Consult #10 item | Section(s) changed |
| --- | --- |
| Edit 1: B = 2 capacity proof (≥ 8×2 I-phase configurations; K_suff = 16) | §5.3, K_suff proofs, B_up = 2 |
| Edit 2: zero-ADAPT construction (register fixed at η₀, encoder reproduces η*, no register-durability payment, T_const; configuration-count sentence) | §5.7, proof steps 3–4 |
| Edit 3: unpaid cells canonicalized to field vectors; UPK-C0 on the observed evidence statistic e with conditional expected reward g(e, c′) | §2.6 (new canonicalization note); §5.5 UPK-C0 row; §15 G3 |
| Edit 4: withdrawal event specified; −3/32 self-test = "On every episode, downgrade the cued field j = c from D to F"; configuration-field withdrawals for general signature evaluation | §8 O-UPK row; §7.1 UPK property |
| Edit 5: unresolved-cell loopholes closed in REJECT-SIG and signature REJECT-NARROW; UNRESOLVED if unresolved cells could qualify; precedence REJECT-ABSENT > REJECT-SIG > REJECT-NARROW; ACC replay record preserved | §7.2 |
| Edit 6: deterministic search accounting (class order, certificate preservation, budget allocation); B_up = 2 decision-bearing for UPK breadth | §11; §12 B_up row |
| G2 accepted | §15 G2 |
| G4 accepted with edit 5 | §15 G4; §7.2 |
| G5 accepted | §15 G5 |
| G8 accepted with qualification (an unfinished required control still blocks family-level ADMIT) | §15 G8; §11 |

**Scratch verification** (outside the repo): `/workspace/scratch/scarcity_final/check.py`, log in `check.log`.
Exact rational arithmetic confirms:
- the minimum is 2 distinct durable pairs per x, so I ≥ 16;
- the two-fixed-pair policy has I = 16, Q = 16 and value 63/64;
- V_full(B_up = 1) = 31/32;
- downgrading the cued field every episode gives ΔV = −3/32;
- downgrading fixed field j = 0 whenever durable gives −1/32.

No search or experiment was run.

## 0. Changes from draft v3 (Consult #8)

| # | Source | Change in v4 |
| --- | --- | --- |
| D1 | Consult #8, highest priority | The false theorem "h = 0 ⇒ ADAPT = 0" is **withdrawn**. With the regime drawn once from (1/2, 1/2), h = 0 gives a **fixed but unknown** regime, and history can reveal it. The zero-ADAPT controls are now **KNOWN-FIXED**, a known fixed query map, and **IID-REGIME**, a regime resampled independently each episode (h = 1/2). Each has a proof (§5.7). The unknown-fixed regime is kept as an **experimental condition with no assumed gap** (§4.3, §5.5, §6, §10, §12). |
| D2 | Consult #8, O-ACC | p and p_guess now condition on the queried item: p_guess = max_b P(X_q = b \| m, q). In paid cells the posterior includes decay. "Every applicable flip has ΔV ≤ 0" is now **proved for unpaid cells only** (feasibility via merging into a reachable configuration) and **removed for paid cells**. O-UPK gets the same query conditioning (§8). |
| D3 | Consult #8, ACC admission | The ACC breadth requirement is **kept unchanged**. ADMIT(ACC) for the storage-attributed claim is unavailable: the first bin holds only K = 1, 2, where the v1 replay shows zero access. **REJECT-NARROW(ACC) is recorded as a known outcome from the v1 replay**, and no search is spent rediscovering it (§7.3). |
| D4 | Consult #8, clean UPK | UPK is renamed **adaptive maintenance allocation**. A cheap rival is added, `cue_blind_upkeep`, whose D-set may depend on raw evidence but not on the cue. UPK splits into UPK_cue and UPK_ev. A new proved control: UPK_cue = 0 at v = 1/3. The proved examples are attributed (§4.1, §5.1, §5.3–§5.5). |
| D5 | Consult #8, signature failure | A resolved, scoped verdict **REJECT-SIG(X)** covers the case "all optima certified, every positive cell NONE or SIG-UNDEFINED". A per-bin signature-failure case is added to REJECT-NARROW (§7.2). |
| D6 | F4 ruling | In K_suff, Opt means the **capacity-unconstrained** optimum for the other fixed cell parameters. Counts are internal configurations only; **supplied external inputs are excluded**, so the stage-A E-phase count is 1 (§2.5, §3.1). |
| D7 | F6 ruling | **K = 24 is not minimal at B_up = 2.** Two durable pairs covering all cues give I = 16 and Q = 16 at the same optimal value. K_suff = 16 at B_up = 2 and 26 at B_up = 1 are now proved (§5.3). |
| D8 | F5, F7, F8, F9, F11 rulings | Accepted as ruled: S2 resampling labelled separately and its magnitude not compared with derangement (§8); graded UPK stays report-only (§5.4); ROUTE positivity is an empirical certificate question, with the 7/8 construction's validity stated (§5.6); ADAPT is value-only (§7.1); T_3 is one declared conventional heuristic (§4.3). |
| D9 | F10 ruling | The signature requirement is **existential only**: each bin needs a positive cell with at least one qualifying optimum. Typicality and robustness are not established (§7.2, §14). |

## 0.1 Changes from draft v2 (retained from v3)

| # | Source | Change in v3 |
| --- | --- | --- |
| C1 | Confirmed results | ACC_suff = 3/32, UPK = 5/96 and UPK = 5/192 are kept, each with an explicit **scope statement**. The UPK bounds hold only under **direct per-query field semantics** (S-DIRECT), clean evidence and ample capacity. They are not claimed for any decoder that can reinterpret other fields (§5.2, §5.3). |
| C2 | Ruling (1) | The history register keeps its 1-unit upkeep charge. O-B1 is closed. No free or persistent register. A free register would be a protected-memory scaffold, i.e. an apparatus change (§4.3, §15). |
| C3 | Ruling (2) | Visible `-` erasure is kept and marked as **supplied access**. The promise to "subtract" it numerically is **withdrawn**. Acquisition attribution would need matched scaffold controls (§9). |
| C4 | Ruling (3) | (3/5, 3/4) is the **only** null. (3/5, 5/8) is excluded **on scope grounds**: its positive ACC_suff is not the reason (§12). |
| C5 | Ruling (4) | δ = 1/2 is primary and δ = 1/4 secondary. The secondary's decision role is frozen: it is report-only and cannot change any primary label. In the proved examples UPK is linear in δ (§5.3, §12). |
| C6 | Blocker (a) | The v2 control "v = 1/3 ⇒ UPK = 0" is **false under graded evidence**. Hand-verified: UPK = **33/4096** at a = r = 3/4, δ = 1/2, B_up = 1 (§5.4). Zero-UPK controls are restricted to **proved** cases (§6). Storage-attributed ACC is restricted to **clean, unpaid** cells. |
| C7 | Blocker (b) | ROUTE at L = 1 is now a **null control** (proof in §5.6). `static_route` is redefined with an explicit information set: the evidence statistic only, with no cue and no encoder-written fields. O-ROUTE's zero identity is re-proved for that definition (§4.2, §8). |
| C8 | Blocker (c) | Explicit **policy semantics per condition** (§2.6): S-DIRECT for all storage and upkeep cells and for stage B; S-MSG only for ROUTE cells. Arbitrary memory decoders are removed from §4. Further changes: K_dec = 8/27 is scoped to the clean/graded **unpaid, full-channel** baseline; a new **K_suff** is min over optimal policies of max over phases of the reachable count (§3); a **frozen outer K grid** is set independently of any solver optimum (§3.3). |
| C9 | Blocker (d) | The O-ACC identities are rewritten with the actual conditional correctness p: answer→abstain changes reward by (r − p), abstain→guess by (p_guess − r), each weighted by P(q \| m). O-SEL and O-ROUTE use a **cue-law-preserving swap kernel**. A derangement kernel exists only if max π(c) ≤ 1/2, so the S2 sweep (2/3, 1/6, 1/6) uses independent resampling (§8). |
| C10 | Blocker (e) | Stage B gains a selectable **constant tracker** (§4.3). The new pieces are: the H = 3 tracker; the timing of register updates, durability payment and erasure; the observation that B_up = 3 no longer guarantees persistence with a fourth field; the scope "positive ADAPT is evidence only against this tracker set"; and a new proof that stationary ADAPT = 0 (§5.7). |
| C11 | Blocker (f) | A per-role **response property** P_X now defines ROBUST / PERMITTED / NONE / SIG-UNDEFINED. NOT-APPLICABLE never counts as a signature (§7.1). |

---

## 1. Scope

**In scope:** C3 pressure and representability for selection (SEL), state-dependent access (ACC), routing across
consumers (ROUTE) and content-dependent upkeep allocation (UPK), within declared finite policy classes.

**Out of scope (unchanged from v2):**
- the social-modelling, curriculum and intrinsic-motivation pressures (GATED / DESIGN-ONLY, `emergence_conditions_v2.md` §3);
- every C4 component;
- the self-induced-uncertainty quantity (UNDEFINED, EXCLUDED);
- any O3 machinery-maintenance bridge.

---

## 2. World family W2′

### 2.1 Items, evidence, cue, reward (unchanged from v2)

| Component | Definition |
| --- | --- |
| Items | x ∈ {0,1}³, i.i.d. uniform |
| Evidence EV | **clean**: exact observation. **graded**: two looks per item, i.i.d. given the item, each correct w.p. a. Statistic n_i ∈ {0,1,2}. |
| a | 3/4 primary; 5/6 secondary; (a = 3/5, r = 3/4) is the **only** null (§12) |
| Cue | c ∈ {0,1,2}, observed at encoding. Primary law π uniform. Sweep S1 = (1/2, 1/4, 1/4) and S2 = (2/3, 1/6, 1/6), descriptive only. |
| Query map | Single consumer: q = c w.p. v, otherwise uniform on the other two; v ∈ {1/3 (uninformative), 3/4}. Two consumers (ROUTE only): A as above; B with c+1 in place of c. |
| Reward | correct answer 1; wrong answer 0; abstain (`-`) r ∈ {5/8, 3/4} |

### 2.2 Memory fields (S-DIRECT cells)

- **Answer fields.** Three answer fields f₀, f₁, f₂ ∈ {0, 1, `-`}.
- **Durability mark.** During phase I, each non-`-` field also carries D or F.
- **History field (stage B only).** A fourth field η ∈ {1..H} with its own D/F mark (§4.3).

### 2.3 Upkeep (unchanged definition)

- **Allocation.** The D-set is chosen at encoding, with |D-set| ≤ B_up.
- **Decay.** At the end of phase I, each F field decays independently w.p. δ: an answer field is erased to `-`;
  η is reset to its initial value. D fields persist.
- **`-` fields.** They cost nothing and cannot decay.
- **Unpaid control.** δ = 0, or B_up ≥ the number of fields: B_up = 3 in stage A, **B_up = 4 in stage B**.

### 2.4 Consumers and channel (ROUTE cells only)

- Channel: L ∈ {1, 2, 3} symbols per consumer, or channel-sufficient L ≥ K_dec,base (8 clean, 27 graded).
- Storage in ROUTE cells is **ample and unpaid**. It is not modelled beyond §2.6.

### 2.5 Phases

- **E (encoding):** inputs (evidence, cue) are **supplied externally and excluded from the count** (F4 ruling).
  The E-phase count is the number of internal configurations carried into encoding: 1 in stage A, and the
  number of reachable η values in stage B.
- **I (upkeep interval):** fields plus marks (plus η in stage B).
- **Q (query):** fields after decay (plus η).
- **Reachable-configuration cap K:** applies in **each** phase separately; integer; duplicates merged (as in v2 §2.4).

### 2.6 Policy semantics, fixed per condition (new; resolves the §2/§5 vs §4 conflict)

| Semantics | Used in | Definition |
| --- | --- | --- |
| **S-DIRECT** (literal fields) | **All** SEL, ACC and UPK cells, unpaid and paid, clean and graded; all of stage B | The encoder maps (evidence, cue[, η]) to field values and a D-set. **The action at query q is the post-decay value of f_q.** There is no decoder, so no field can be reinterpreted. An erased field abstains. This is the v1 replay's codeword language, where a configuration *is* its action vector. |
| **S-MSG** (messages) | ROUTE cells only | The sender sees the information set allowed by its class (§4.2) and emits μ_j ∈ {1..L} to each consumer j. Consumer j acts by an arbitrary decoder d_j(μ_j, q_j). Memory is ample and unpaid, so the sender's information set is available losslessly (K ≥ 3·K_lossless: 24 clean, 81 graded). |

**Unpaid canonicalization (Consult #10, edit 3).** Unpaid S-DIRECT cells use **field vectors only**, with
durability marks omitted or uniquely determined by those vectors. The configuration in every phase of an unpaid
cell is the written field vector.

**Equivalence note.** In unpaid single-consumer cells, S-DIRECT gives the same optimal values as a decoder
language: any decoder over K abstract labels defines K action vectors. In paid cells the two differ, because a
decoder could read other fields after an erasure. **This protocol adopts S-DIRECT for paid cells.** No result
is claimed for the decoder language there (flag F3).

---

## 3. Capacity notions

### 3.1 Definitions

| Notion | Definition | Scope |
| --- | --- | --- |
| **K_lossless** | number of values of the evidence sufficient statistic: 8 clean, 27 graded | descriptive |
| **K_dec,base** | the minimal per-phase count at which the unconstrained optimum is attained, in the **clean/graded, unpaid, single-consumer, full-channel baseline**. Clean 8. Graded 27 for (3/4, ·) and (5/6, ·). 1 for the null (3/5, 3/4). | **only** that baseline (Astra #6) |
| **K_suff(cell)** | **min over π ∈ Opt of [max over phases ∈ {E, I, Q} of the reachable count N_phase(π)]**. **Opt** = the policies attaining the **capacity-unconstrained** optimum for the other fixed cell parameters (B_up, δ, evidence, v, r, L, H). N_phase counts **internal** configurations, excluding supplied external inputs (§2.5). Defined for every cell (paid, stage B, ROUTE); it equals K_dec,base on the baseline. | general; computed at run time unless proved in §5 |

Astra #8 confirmed this reading (F4): the minimum is over optimal policies and the maximum over phases. Without
the input exclusion, E-phase counting would conflict with the baseline values 8 and 27.

### 3.2 Rules

- **Sufficiency control.** K ≥ K_suff(cell).
- **ACC/SEL gate bins.** These are indexed by K / K_dec,base. For paid cells this ratio is a **frozen index,
  not a sufficiency claim**.

### 3.3 Frozen outer K grid (independent of any solver optimum)

**K ∈ {1, 2, 3, 4, 6, 8, 12, 16, 18, 24, 26, 27, 32, 48, 64, 96, 125}** for stage A.

**Why 125 is ample.** Under S-DIRECT, the stage-A I-phase count is at most Σ over patterns of field states.
Each field is `-`, or one of 2 values × 2 marks, i.e. 5 states, giving ≤ 5³ = 125. The Q-phase count is
≤ 3³ = 27. So K = 125 admits **every** stage-A policy.

**Stage B.** The grid is the stage-A grid × {1, H, 2H}, capped at the ample value 125·2H. The η field has H
values × 2 marks.

**Inclusion.** Grid points are included whether or not they coincide with an optimum's count. 16, 18, 24 and 26
are included because §5 uses them as proved or sufficient thresholds, not because a solver found them. The grid
itself is unchanged from v3.

---

## 4. Policy classes

### 4.1 Stage A, S-DIRECT

| Class | Restriction relative to `full` (everything else matched) |
| --- | --- |
| `full` | Any deterministic encoder (evidence, cue) → (fields, D-set), within per-phase K and B_up |
| `cue_blind` | Encoder and D-set independent of the cue |
| `static_access` | All reachable **Q-phase** configurations share one `-` pattern. Under paid upkeep this is usually infeasible except with all-D or all-`-` patterns, so paid-cell ACC is descriptive (§5.5). |
| `fixed_upkeep` | D-set = a fixed index set of size ≤ B_up, independent of evidence and cue |
| `cue_blind_upkeep` (new, D4) | D-set may depend on the **raw evidence** but **not** on the cue. Encoding of the field values is otherwise unrestricted, as in fixed_upkeep. It is one extra class per UPK cell, inside the same 10-CPU-min cell budget. |
| `random_yoke` | Descriptive only |

### 4.2 ROUTE classes, S-MSG

| Class | Information set of the sender | Message map |
| --- | --- | --- |
| `full_route` | (EVstat, c): EVstat = x (clean) or (n₀, n₁, n₂) (graded) | μ_j = g_j(EVstat, c), arbitrary |
| `static_route` | **EVstat only.** The permitted "fields" are the three raw evidence-statistic fields. There is no cue, no encoder-written field, and no access to the other consumer's query. | μ_j = g_j(EVstat), arbitrary but cue-independent |

**What static_route denies.** It denies exactly the cue-dependent choice of which content is sent to which
consumer, i.e. routing. Because its inputs are raw evidence fields and not cue-dependent encoded fields, Astra's
leak ("a cue-independent router can still receive cue-dependent encoded fields") cannot arise.

**Consumers.** Consumer decoders d_j are arbitrary in both classes.

**Value.** The mean of the two consumers' expected rewards.

### 4.3 Stage B (repaired comparator v3)

| Element | Definition |
| --- | --- |
| Regime | Consumer A's query map is c in regime 0 and c+1 in regime 1. **Conditions:** (i) **SWITCHING**: hidden hazard h = 1/4 per episode (PROPOSED; primary experimental condition). (ii) **UNKNOWN-FIXED**: h = 0, with the regime drawn once from (1/2, 1/2). This is an **experimental condition with no assumed gap**, since history can reveal the regime (Consult #8). (iii) **Zero-ADAPT controls:** **KNOWN-FIXED**, where the regime is a fixed constant of the world (regime 0, map = c) with no draw; and **IID-REGIME**, where h = 1/2, so the regime is redrawn uniformly and independently before every episode. |
| η field | η ∈ {1..H}; H = 2 primary; H ∈ {1, 3} report-only. η₀ = 1 for H = 2 and η₀ = 2 for H = 3. Erasure resets η to η₀. |
| Charging | (η, fields, marks) are jointly counted per phase against K. **η costs 1 unit of B_up per episode to be durable (ruling (1)).** A free or persistent η would be a protected-memory scaffold and is **not** used. |
| Fields and B_up | There are **four** fields (f₀, f₁, f₂, η). **B_up = 3 no longer guarantees that everything persists.** The unpaid control is B_up = 4 or δ = 0. |
| **Timing (episode t)** | 1. **E_t:** the encoder reads (evidence_t, c_t, η_t) and writes f₀..f₂ and a D-set ⊆ {f₀, f₁, f₂, η} with \|D\| ≤ B_up. This is the only durability payment of episode t. 2. **End of I_t:** each fragile field decays w.p. δ, so answer fields → `-` and η → η₀. Call the result η̃_t. 3. **Q_t:** query q_t; action = post-decay f_{q_t}; reward. 4. **Feedback:** (q_t, c_t, outcome_t ∈ {correct, wrong, abstained}). 5. **Update:** η_{t+1} = g(η̃_t, q_t, c_t, outcome_t), used at E_{t+1}. |
| `full_B` | Encoder and D-set are arbitrary functions of (η, evidence, cue); g is optimized. |
| `adaptive_select` (v3) | The encoder and D-set are optimized given η. **g is selected from the fixed set {T_const, T_H}**; the class value is the max of the two. **T_const:** η_{t+1} = η₀ always. Its reachable η count is 1 and it never needs η upkeep. **T_2:** η′ = 1 if q = c; η′ = 2 if q = c+1; else η′ = η̃. **T_3 (saturating counter; accepted per F11 as one declared conventional heuristic, not the strongest possible adaptive filter):** if q = c then η′ = max(η̃ − 1, 1); if q = c+1 then η′ = min(η̃ + 1, 3); else η′ = η̃. Here 1 = "regime c likely", 3 = "regime c+1 likely" and 2 = neutral. |
| `ADAPT` | V_full_B − max(V_{T_const}, V_{T_H}). It is also reported per tracker. **Scope:** a positive ADAPT is evidence only against **this** tracker set {T_const, T_H} at equal H, K, feedback and upkeep, not against conventional adaptive selection in general. |
| Value | The Cesàro long-run average from the condition's initial law (regime law and η₀), computed through the chain's limiting matrix (unchanged from v2). |

---

## 5. Analytic facts (hand-derived; scope stated per item)

### 5.1 Frozen definitions (unchanged)

- Access = V_full − V_static_access.
- Selection = V_full − V_cue_blind.
- ROUTE = V_full_route − V_static_route.
- UPK = V_full − V_fixed_upkeep, now named **adaptive maintenance allocation** (D4). It denies dependence on both
  evidence and cue, so in general it is **not** cue-attributed.
- **UPK_cue** = V_full − V_cue_blind_upkeep (**cue-attributed maintenance**) and **UPK_ev** = V_cue_blind_upkeep −
  V_fixed_upkeep (evidence-dependent maintenance). UPK = UPK_cue + UPK_ev.
- ADAPT as in §4.3.

### 5.2 ACC_suff (v2 table retained)

**Scope.** Single consumer, unpaid, K ≥ K_dec,base, S-DIRECT.

| (a, r) | ACC_suff |
| --- | --- |
| clean | 0 |
| (3/4, 3/4) | **3/32** (confirmed by Astra #6) |
| (3/4, 5/8) | 3/64 |
| (5/6, 3/4) | 5/72 |
| (5/6, 5/8) | 5/144 |
| (3/5, 3/4) | **0, all-abstain null** |

Graded ACC_suff is ordinary selective prediction under observation uncertainty and is **never**
storage-attributed.

### 5.3 UPK > 0 under clean evidence (confirmed), with δ-scaling

**Scope.** S-DIRECT; clean evidence; single consumer; v = 3/4; r = 3/4; uniform cue; K ≥ the thresholds below.
These are not claimed for decoder semantics.

**Values.** An answered fragile field is worth (1−δ)·1 + δ·r = 1 − δ/4.

- **B_up = 1.**
  - V_full = 3/4 + (1/4)(1 − δ/4) = 1 − δ/16.
  - V_fixed = 1/3 + (2/3)(1 − δ/4) = 1 − δ/6.
  - **UPK = 5δ/48.** δ = 1/2 → **5/96** (confirmed); δ = 1/4 → 5/192.
- **B_up = 2.**
  - V_full = 1 − (1/8)(δ/4) = 1 − δ/32.
  - V_fixed = 1 − (1/3)(δ/4) = 1 − δ/12.
  - **UPK = 5δ/96.** δ = 1/2 → **5/192** (confirmed); δ = 1/4 → 5/384.

The upper bound holds because, under S-DIRECT, a field can only answer its own query, and full protects the
most probable queries.

**Attribution (D4).** In these clean, ample-capacity cells, V_cue_blind_upkeep = V_fixed.
- Every field is answered correctly (p = 1).
- A cue-blind D-set j(x) faces P(q = j(x)) = 1/3, because c is uniform and independent of x. So no
  evidence-dependent choice beats a fixed one.
- Hence **UPK_cue = UPK = 5δ/48 (B_up = 1) and 5δ/96 (B_up = 2)**, and UPK_ev = 0.
- This attribution is proved **only** for these ample-capacity examples. Under compressed storage, clean
  evidence can still affect which fields are worth protecting (Consult #8), and UPK_cue is computed.

**K thresholds** (S-DIRECT counts):

| B_up | full: phase I | full: phase Q | fixed: phase I | fixed: phase Q | K needed for the stated full policy |
| --- | --- | --- | --- | --- | --- |
| 1 | 24 | 26 | 8 | 18 | **K ≥ 26** |
| 2 (cyclic, three pairs) | 24 | 20 (≤ 1 erased field) | 8 | 12 | K ≥ 24 (sufficient, **not minimal**) |
| 2 (two pairs, D7) | **16** | **16** | 8 | 12 | **K ≥ 16** |

**K_suff proofs (D7).**
- **Every field is stored.** In both cells, every optimal policy stores every field, because a fragile answered
  field gives 1 − δ/4 > r.
- **B_up = 2.**
  - For each fixed item vector x, all three cues have positive probability. An optimal policy answers every field
    correctly and uses a durable pair containing the cue. Therefore it needs at least two distinct durable pairs
    for each x. Different item vectors have different field values, giving at least 8×2 = 16 I-phase
    configurations. The displayed policy using two fixed pairs attains I = 16 and Q = 16. Hence K_suff = 16.
  - Example of the displayed policy: {0,1} for c ∈ {0,1} and {0,2} for c = 2.
  - Independence does not make an evidence-dependent D-set independent of x. A universal Q-phase lower bound is
    unnecessary.
  - **K_suff = 16.**
- **B_up = 1.**
  - The D-set must be {c}, so I = 8·3 = 24.
  - Q = every pattern except all-erased = 8 + 3·4 + 3·2 = 26.
  - **K_suff = 26.**

Below K_suff, UPK is computed, not assumed. Astra confirmed the v3 counts as sufficient counts (F6).

### 5.4 Graded evidence breaks the "v = 1/3 ⇒ UPK = 0" control (Blocker (a), verified)

**Setup.** S-DIRECT; graded; a = r = 3/4; δ = 1/2; B_up = 1; v = 1/3 (uniform query, independent of cue and
items); ample K (≤ 125 by §3.3).

**Per item.**
- P(agree) = a² + (1−a)² = 5/8, with confidence 9/10 > r. That field is answered.
- P(disagree) = 3/8, with confidence 1/2 < r. That field is `-`, which neither needs nor benefits from
  durability.

**Gain from durability.** Making an answered field durable gains δ(9/10 − r)·P(q = j) = (1/2)(3/20)(1/3) = 1/40.
Answering a fragile field is never worse than `-`, since (1−δ)(9/10) + δr ≥ r. So:

- V_full = base + (1/40)·P(at least one field agrees) = base + (1/40)(1 − (3/8)³) = base + (1/40)(485/512).
- V_fixed = base + (1/40)·P(fixed field j agrees) = base + (1/40)(5/8) = base + (1/40)(320/512).

**UPK = (1/40)(165/512) = 165/20480 = 33/4096 > 0.**

This matches Astra's formula δ(9/10 − r)/3 · [P(≥1 agreement) − P(fixed field agrees)]. Exact rational arithmetic
gives 33/4096 at δ = 1/2 and 33/8192 at δ = 1/4, again linear in δ.

**Interpretation.** Even with an uninformative cue, full allocates durability to **evidence-dependent** content
(an agreeing look), not cue-dependent content. Splitting the value (D4):
- the rule "protect an agreeing field" uses evidence only, so V_cue_blind_upkeep = V_full here;
- hence **UPK_cue = 0** and **UPK_ev = 33/4096**.

Graded UPK stays **report-only** (F7 ruling). A separate reliability contrast would be a separately specified
question.

### 5.5 Proved zero controls (only these are controls)

| Control | Proof sketch | Scope |
| --- | --- | --- |
| **UPK-Z1:** B_up = 0 | No D writes in either class | all cells |
| **UPK-Z2:** B_up ≥ number of fields (3 in stage A) | All fields durable in both classes | all stage-A cells |
| **UPK-Z3:** δ = 0 | Durability is irrelevant | all cells |
| **UPK-Z4:** clean, v = 1/3, B_up = 1, K ≥ 18 | Every field answered correctly is weakly optimal (1 − δ/4 ≥ r). P(q = j) = 1/3 for every j, so any single D field yields 1 − (2/3)(δ/4) and that is also full's upper bound. The fixed all-answer policy needs ≤ 8 (I) and 18 (Q) configurations. | clean, S-DIRECT only. **Not graded** (§5.4). |
| **UPK-Z4′:** clean, v = 1/3, B_up = 2, K ≥ 12 | Same argument, with fixed counts 8 (I) and 12 (Q) | clean, S-DIRECT |
| **UPK-C0 (new, D4):** v = 1/3 ⇒ **UPK_cue = 0**, for any evidence, K, B_up and δ (stage A) | Let e be the **observed evidence statistic** (e = x for clean evidence, e = (n₀, n₁, n₂) for graded), not the latent x. The query is independent of (e, c), and decay is independent of everything. Define **g(e, c′)** as the conditional expected reward, given e, of applying full's output for cue c′. It does not depend on the true c. Hence V_full = E_e E_c g(e, c) ≤ E_e max_{c′} g(e, c′). Then selecting c*(e) is an admissible encoder: it applies full's (fields, D-set) at c*(e), is a function of e only and hence cue-blind, and so lies in cue_blind_upkeep. Its reachable sets are subsets of full's, so it fits K. | S-DIRECT, stage A |
| **ACC-Z:** clean, **unpaid**, K ≥ 8 | full stores x (V = 1). An all-answer static pattern also gives V = 1. | clean, unpaid only. Storage-attributed ACC is claimed only in clean, unpaid cells. |
| **NULL:** (a = 3/5, r = 3/4), any K, any B_up, any class | Every answer has conf ≤ 9/13 < r. All-`-` attains r, needs no upkeep and fits K = 1. Every class therefore has V = r and every role difference is 0. | graded |
| **SEL-Z:** v = 1/3, unpaid, any K | The query is independent of (c, x), so a cue-dependent choice among codebook entries is never better than the best fixed choice | S-DIRECT |
| **ROUTE-Z1:** L = 1 | Both classes send a constant message, so the decoders face identical information | §5.6 |
| **ROUTE-Z2:** v = 1/3 | Queries are independent of (c, x). V_full_route = E_c[V(g(·, c))] ≤ max_c V(g(·, c)), which static_route attains with g(·, c*). | S-MSG |
| **ROUTE-Z3:** L ≥ K_dec,base (8 clean, 27 graded) | The per-query optimal action depends on evidence only, never on c. static_route sends the full optimal action profile. | S-MSG |
| **ADAPT-Z1:** H = 1 | Both arms coincide | stage B |
| **ADAPT-Z2:** KNOWN-FIXED and IID-REGIME conditions | §5.7. **Not** the unknown-fixed h = 0 condition, which is experimental with no assumed value. | stage B, with T_const in the class |
| **K = 1** | DEGENERATE | all |

**Removed as controls.** v2's "UPK = 0 at v = 1/3" in graded cells is false (§5.4). Paid-cell ACC is not a
control and is not storage-attributed: paid erasure can create access variation without storage scarcity.

### 5.6 ROUTE at L = 1 is a null

With one symbol, μ_j is constant in both classes. Each consumer's best decoder is then the same function of q_j
alone, so V_full_route = V_static_route and ROUTE = 0. L = 1 moves from "required positive bin" to **null
control**.

**Positive ROUTE bins.** L ∈ {2, 3} (PROPOSED). Positivity is an **empirical certificate question** (F8 ruling).

The construction "consumer A receives x_c and consumer B receives x_{c+1}, i.e. each consumer gets **its own
preferred item's bit** and always answers" is valid. At clean, v = r = 3/4, L = 2 it gives V_full_route ≥ 7/8.

A feasible lower bound alone establishes **no gap** against static_route, so no sign is claimed.

### 5.7 Zero-ADAPT controls: KNOWN-FIXED and IID-REGIME (v4 proof; replaces v3's false h = 0 theorem)

**What was wrong in v3.** With h = 0 and the regime drawn once from (1/2, 1/2), the regime is fixed but unknown.
η_t becomes correlated with it through feedback, so the per-slice values are not exchangeable across η, and the
best-slice argument fails (Consult #8). This **UNKNOWN-FIXED** case is now an experimental condition. Any ADAPT
value there, including a positive one, is a legitimate result and is **not** an implementation error.

**Setup for the controls.**
- **KNOWN-FIXED:** the regime is a world constant.
- **IID-REGIME:** the regime is redrawn independently and uniformly before each episode.

In both, the episode variables W_t = (regime_t, evidence_t, c_t, q_t, decay draws_t) are i.i.d. across t and
independent of the past. η_t is a function of the past only, so **W_t ⊥ η_t**.

**Proof.**
1. The expected reward of episode t given η_t = η is v(η), the one-episode value of slice η. This includes that
   slice's D-set, possibly spending B_up on η. v(η) does not depend on t or on the history, by step 0.
2. The long-run average of full_B is a Cesàro average of E[v(η_t)], which is ≤ max_η v(η) = v(η*).
3. Under T_const the register is kept **physically fixed at the declared η₀**. Its encoder is defined to
   **reproduce the best slice η\***: at η₀ it writes exactly the answer values and answer-durability choices that
   full_B's slice η* writes. Those are left unchanged, and any register-durability payment is removed. Register
   durability does not affect answer rewards, and erasure resets η to η₀, so the register never changes and its
   value is v(η*).
4. Mapping register values to η₀ and removing its durability mark cannot increase the number of reachable
   configurations.
5. Hence V_{T_const} ≥ V_full_B and ADAPT = 0 under both controls.

**Why T_const is needed.** The fixed trackers force η changes, which consume K and possibly B_up (v3 point
retained).

---

## 6. Controls applied per role

| Role | Controls (all proved in §5.5) | If violated |
| --- | --- | --- |
| ACC | ACC-Z (clean, unpaid, K ≥ 8); NULL; K = 1. The admission outcome is already known (§7.3). | implementation error |
| SEL | SEL-Z; NULL | implementation error |
| UPK | UPK-Z1, Z2, Z3; UPK-Z4/Z4′ (clean only); **UPK-C0 (UPK_cue = 0 at v = 1/3)**; NULL; **positive self-tests**: §5.3 values at K ≥ 26 (B_up = 1) and K ≥ 16 (B_up = 2), with UPK_cue = UPK there; **§5.4 33/4096** (graded, v = 1/3, ample K), with UPK_cue = 0 and UPK_ev = 33/4096 | implementation error |
| ROUTE | ROUTE-Z1 (L = 1), Z2 (v = 1/3), Z3 (L ≥ K_dec,base) | implementation error |
| ADAPT | ADAPT-Z1; ADAPT-Z2 (KNOWN-FIXED and IID-REGIME only). UNKNOWN-FIXED is **not** a control. | implementation error |
| all | the v1 replay slice (clean, unpaid, single consumer, S-DIRECT) reproduces `replay_results.json` | implementation error |

Any cell not listed here is **not** a control and carries no predicted value.

---

## 7. Outcome semantics

### 7.1 Per cell

**Value labels (unchanged from v2).** CERT-POS(X), CERT-ZERO(X), UNRESOLVED, INFEASIBLE, DEGENERATE.

**Response property P_X (new; Blocker (f)).** Each property is evaluated on one optimal `full`-class policy π
in exact arithmetic.

| Role | P_X(π) holds iff |
| --- | --- |
| SEL | the O-SEL response ΔV(π) < 0 strictly (by §8, cue_blind has ΔV = 0 exactly) |
| ACC | (i) π's reachable Q-configurations show ≥ 2 distinct `-` patterns; **and** (ii) at least one O-ACC flip is APPLICABLE with ΔV < 0 strictly. In paid cells, (i) must hold among **pre-decay** (phase-I) patterns, so that erasure alone cannot satisfy it. |
| UPK | (i) π's D-set varies with (evidence, cue) on a set of positive probability; **and** (ii) at least one APPLICABLE O-UPK withdrawal, an explicitly identified configuration-field withdrawal (§8), has ΔV < 0 strictly |
| ROUTE | the O-ROUTE response ΔV(π) < 0 strictly (static_route has ΔV = 0, §8) |
| ADAPT | **not evaluated.** ADAPT is value-only (F9 ruling, accepted): it is a narrowly stated optimization-gap result against the specified trackers {T_const, T_H}. |

**Signature labels.** These are assigned only after the optimum set is complete, up to item symmetry.

| Label | Condition |
| --- | --- |
| ROBUST(X) | every optimum satisfies P_X |
| PERMITTED(X) | some but not all optima satisfy P_X |
| NONE(X) | no optimum satisfies P_X, and at least one optimum has an applicable operator |
| SIG-UNDEFINED(X) | the operator is NOT-APPLICABLE on every optimum |
| UNRESOLVED | the optimum set is not certified complete |

NOT-APPLICABLE never counts toward P_X.

### 7.2 Per role X

**ADMIT(X)** requires all of:
1. every §6 control for X passes;
2. CERT-POS(X) in at least one cell in each declared bin;
3. in each bin, at least one CERT-POS cell has **at least one qualifying optimum**, i.e. it is labelled ROBUST(X)
   or PERMITTED(X). This requirement is **existential only** (F10 ruling): it establishes neither typicality nor
   robustness across optima. ROBUST counts are reported separately.
4. no control is UNRESOLVED.

**Bins.**

| Role | Bins |
| --- | --- |
| SEL, ACC | K / K_dec,base ∈ (0, 1/4], (1/4, 1/2], (1/2, 1). Restricted to frozen grid points. ACC bins use clean, unpaid cells only for storage-attributed claims. **This breadth requirement is unchanged and is not revised to rescue ACC (§7.3).** |
| ROUTE | L = 2, L = 3. L = 1 is a null control. |
| UPK | B_up ∈ {1, 2}. ADMIT(UPK) is the **adaptive maintenance allocation** claim (V_full − V_fixed_upkeep). The **cue-attributed** sub-claim needs UPK_cue to meet requirements 2–3 in clean cells. Graded cells are report-only (§5.4). |

**REJECT-SIG(X) (new, D5): a resolved signature-failure verdict.** It applies when:
- CERT-POS(X) holds in at least one cell;
- **every in-scope cell's value status is resolved** (Consult #10, edit 5): no in-scope cell has an UNRESOLVED
  value label;
- the optimum set is certified complete in **every** CERT-POS cell, so no signature label is UNRESOLVED;
- **every** CERT-POS cell is labelled NONE(X) or SIG-UNDEFINED(X);
- all controls pass.

Its scope: "In W2′, the task rewards role X in value over the declared rival, but no certified optimum in any
positive cell exhibits the declared response property P_X. The declared signature fails as a discriminator of X
here." It does **not** reject role X or C3, and it is **not** computational uncertainty, so it is never reported
as UNRESOLVED.

**REJECT-NARROW(X), extended (G4 accepted with Consult #10, edit 5).** REJECT-NARROW also covers signature
breadth. Signature-based REJECT-NARROW requires all of the following:
- **every value status in the failing bin is resolved**;
- **every positive cell there is certified NONE/SIG-UNDEFINED**;
- **another bin must qualify**.

**Unresolved cells.** If unresolved cells could supply a qualifying optimum, use **UNRESOLVED**.

**Precedence.** Where rejection categories overlap, use **REJECT-ABSENT, then REJECT-SIG, then REJECT-NARROW**.
ACC's separately established, replay-based REJECT-NARROW record (§7.3) is preserved.

**Other verdicts and stop rule.** REJECT-ABSENT and UNRESOLVED are unchanged from v2. UNRESOLVED now excludes
the REJECT-SIG case. The stop rule is unchanged: Stage B runs only for roles that reach CERT-POS, and a stage B
that is not run is recorded as "B not reached".

### 7.3 Known ACC outcome (D3): REJECT-NARROW(ACC), recorded from the v1 replay

**The bin.** For the storage-attributed ACC claim (clean, unpaid, K_dec,base = 8), the first bin K/8 ∈ (0, 1/4]
contains only the grid points K = 1 (DEGENERATE, all differences 0) and K = 2.

**What the replay shows.** The independent exact v1 replay (`/workspace/scratch/scarcity_replay/replay_results.json`,
which matched SCARCITY_GAP_v1 §5) reports access = 0 at K = 1 and K = 2 in all four in-scope cells
(v, r) ∈ {1/3, 3/4} × {5/8, 3/4}.

It also reports positive access elsewhere:
- K = 3: 1/48 and 1/24 at v = 1/3; 1/192 at v = r = 3/4;
- K = 6: 1/48 and 1/24 at v = 1/3.

**Consequence.**
- Requirement 2 of ADMIT(ACC) cannot be met, so **ADMIT(ACC) is unavailable**.
- The recorded outcome is **REJECT-NARROW(ACC)**: pressure is present but not widespread across the declared
  storage bins. This is **known in advance from the v1 replay**.
- The breadth requirement is **not** revised.
- **No search is spent rediscovering this.** The replay slice remains a §6 implementation control.
- Paid and graded ACC values may be reported descriptively but cannot change this label.

Per v2 §7.2, REJECT-NARROW means the task/parameter family fails as the proposed discriminator. It does not
reject C3.

---

## 8. Intervention operators (v3)

**Cue-law-preserving kernel κ(c′ | c) (new).** Used by O-SEL and O-ROUTE.

- **Requirement.** Σ_c π(c) κ(c′|c) = π(c′), with c′ drawn independently of x given c.
- **Derangement version (c′ ≠ c).** This exists iff max π(c) ≤ 1/2, because the flow out of the largest cue
  must fit into the others.
  - Uniform: κ = uniform on the other two.
  - S1 (1/2, 1/4, 1/4): κ(·|0) = (0, 1/2, 1/2); κ(·|1) = κ(·|2) = (1, 0, 0). Check: column sums are
    1/4 + 1/4 = 1/2, 1/4 and 1/4.
  - S2 (2/3, 1/6, 1/6): **no derangement exists** (2/3 > 1/3).
- **Resample version.** κ(c′|c) = π(c′), allowing c′ = c. It is defined for every π.
- **Primary choice.** Derangement for uniform and S1; resample for S2 (F5 ruling, accepted).
- **Labelling.** Resample-based results are labelled **O-SEL-R / O-ROUTE-R**, separately from the derangement
  versions. Their magnitudes are **not directly comparable** with derangement responses without accounting for
  the different intervention. Resampling preserves the cue law and the cue_blind / static_route zero identities.

**Operators.**

| Operator | Definition | Proved identity |
| --- | --- | --- |
| **O-SEL** | Encode under c; draw q from P(q \| c′), with c′ ~ κ(·\|c) | **cue_blind: ΔV = 0.** Its encoding depends only on x. c′ is independent of x with marginal π, so the joint law of (x, q) is unchanged. full: computed. |
| **O-ACC** | On a reachable Q-configuration m and queried item q, flip field q: answer → `-`, or `-` → the bit b* = argmax_b P(X_q = b \| m, q). All other fields are unchanged. APPLICABLE only if m′ is reachable under the same policy; otherwise NOT-APPLICABLE. | **Query-conditioned (D2).** ΔV = P(m, q)·(r − p) for answer→abstain, with **p = P(f_q correct \| m, q)**. ΔV = P(m, q)·(p_guess − r) for abstain→guess, with **p_guess = max_b P(X_q = b \| m, q)**. Both posteriors condition on q, because observing q is informative about the cue. **In paid cells the posterior over (evidence, cue, pre-decay configuration, D-set) given (post-decay m, q) includes the decay probabilities.** **Sign:** in **unpaid** cells, every APPLICABLE flip has ΔV ≤ 0 at a full optimum. *Proof:* with δ = 0, the configuration in phases I and Q is the written field vector. The policy that sends every input previously encoded to m to the already-reachable m′ is an admissible full encoder. Its reachable sets per phase are those of π minus m, so it fits K. Its value is V + ΔV, so optimality gives ΔV ≤ 0. **In paid cells this claim is removed.** A post-decay replacement need not be implementable by any admissible S-DIRECT encoder, so ΔV is computed with no sign asserted. |
| **O-UPK** | At encoding, downgrade one D field from D to F on **explicitly identified encoding events** | **Withdrawal event (Consult #10, edit 4).** An O-UPK result must identify both the field and the encoding events on which it is downgraded. **For the −3/32 self-test: On every episode, downgrade the cued field j = c from D to F.** In the §5.3 cell (B_up = 1) this gives −δ·P(q = c \| c)·(1 − r) = −(1/2)(3/4)(1/4) = −3/32. Withdrawing one fixed field j whenever it is durable instead gives −1/32 in that example; that is a different event. **For general signature evaluation, use explicitly identified configuration-field withdrawals, integrating their event probabilities.** This prevents confusing a conditional loss with a whole-distribution loss. **Query-conditioned (D2).** For a withdrawal of field j on the event set A of pre-decay configurations m̂ (j durable and answered): ΔV = −δ·Σ_{m̂ ∈ A} P(m̂)·P(q = j \| m̂)·(p_j(m̂, q = j) − r), where p_j(m̂, q = j) = P(f_j correct \| m̂, q = j). **No sign or feasibility claim** is made in general: the withdrawn policy may add I-phase configurations. Withdrawing η's durability in stage B is computed, with no closed form. |
| **O-ROUTE** | Route under c; draw both consumers' queries under c′ ~ κ(·\|c) | **static_route: ΔV = 0.** Its messages are functions of EVstat only (§4.2), and (EVstat, q_A, q_B) has the same law under κ. This identity requires the v3 static_route definition. Under v2's definition (encoder-written fields) it did not follow. |

Dropped operators remain dropped (as in v2): the message swap; L-reduction as a lesion; "static router loses
uniformly"; the random_yoke prediction.

These remain representability statements about optima (Q-EXIST). Q-CAUSE in any developed system needs a
separately authorized study.

---

## 9. Scaffold accounting (v3)

| Role | Supplied | Chosen by optimization | Denied by rival | Later learner must acquire (ORIGIN: untested) |
| --- | --- | --- | --- | --- |
| SEL | cue access at encoding; field-per-query layout (S-DIRECT); K | cue-conditioned field map | cue dependence (cue_blind) | cue-conditioned retention in a generic state |
| ACC | the `-` action. **Under paid upkeep, visible erasure-to-`-` is SUPPLIED ACCESS (ruling (2)).** It is marked, never numerically subtracted. | which configurations abstain | state dependence of abstention | state-dependent abstention. Attribution against supplied erasure requires **matched scaffold controls**, e.g. an otherwise identical cell with hidden decay, designed later and separately approved. No additive decomposition is assumed. |
| ROUTE | message alphabet L; consumer decoders; the evidence-statistic fields (S-MSG) | message and decoder maps | cue dependence of messages | co-adapted sender/receiver conventions |
| UPK (adaptive maintenance allocation) | the D/F write, unit cost, decay, per-field granularity | the D-set as a function of (evidence, cue) | evidence and cue dependence of the D-set (fixed_upkeep); **cue dependence only (cue_blind_upkeep), for UPK_cue** | content-dependent maintenance without a designated durable operation |
| ADAPT | η field (charged, **paid upkeep**, not protected); feedback alphabet; timing (§4.3); the tracker set {T_const, T_H} | encoder/D-set given η; in full_B, also g | an optimized g | an acquired history update |

---

## 10. Adaptive rival

Unchanged from v2: the rival is necessary but is not an acquisition test. Two additions in v3:
- ADAPT is scoped to the tracker set {T_const, T_H};
- ADAPT = 0 is proved under KNOWN-FIXED and IID-REGIME (§5.7, v4). The unknown-fixed h = 0 case is
  experimental, with no assumed value (Consult #8).

---

## 11. Computation accounting

Unchanged from v2 §11:
- 10 CPU-min per cell, aggregated across workers, with restarts included;
- certificates checkpointed every 3 CPU-min;
- a timeout means UNRESOLVED;
- a 30-min sensitivity re-run is report-only.

The frozen outer K grid (§3.3) is part of the pre-search freeze.

**Deterministic search accounting (Consult #10, edit 6).** These rules are frozen with the protocol.

**Class-search order within a cell:**
1. `full` (value, then all-optima certification, then the §8 intervention / signature analysis);
2. the role-denied rivals present in the cell, in this fixed order: `cue_blind`, `static_access`,
   `fixed_upkeep`, `cue_blind_upkeep`, `static_route` (ROUTE cells contain only `full_route` and `static_route`);
3. stage B: `full_B`, then `adaptive_select` with T_const, then with T_H.

**Allocation of the shared ten-minute budget.**
- `full`'s value search, all-optima certification and signature analysis receive the first 4 CPU-min.
- The remaining 6 CPU-min are split equally among that cell's rivals in the order above.
- Unused time rolls forward to the next class in order.
- Time left after the last rival returns to `full`'s unfinished certification or signature analysis, if any.
- The 3-CPU-min checkpoints are taken on cumulative cell time.

**Certificate preservation.**
- Every completed value certificate, all-optima certificate and signature label is written to the cell record
  at completion and at each checkpoint.
- **Completed value and signature certificates are preserved when another class times out.** A timeout makes
  only the role differences that need the unfinished class UNRESOLVED.
- Per G8 (accepted with qualification): a timeout can leave UPK certified while UPK_cue remains UNRESOLVED.
  However, **an unfinished required control still blocks the corresponding family-level ADMIT** under the
  declared rules (§7.2 requirement 4).

---

## 12. Parameters

| Item | Status |
| --- | --- |
| a | 3/4 primary; 5/6 secondary |
| (a, r) null | **(3/5, 3/4) only** |
| (3/5, 5/8) | **Excluded on scope grounds** (limited grid). Its ACC_suff = 7/200 is recorded but is not the reason. |
| δ | **1/2 primary; 1/4 secondary.** The secondary's **decision role is frozen as report-only**: it cannot create, remove or change any CERT, signature or ADMIT/REJECT label. Expected scaling in the proved examples: UPK ∝ δ (5δ/48, 5δ/96, and the graded 33/4096 → 33/8192). |
| B_up | 1 primary; 2 secondary. **B_up = 2 is explicitly decision-bearing for the UPK breadth test** (§7.2 bins B_up ∈ {1, 2}), despite being called "secondary". It is not report-only like secondary δ. Stage A controls are 0 and 3. **Stage B unpaid control is 4.** |
| History upkeep | **Charged: 1 unit per episode for durable η (ruling (1)).** No free register. |
| K | the frozen outer grid (§3.3) |
| H | 2 primary; {1, 3} report-only. T_2 and T_3 are as in §4.3 (T_3 accepted per F11). |
| h | SWITCHING 1/4 (PROPOSED, primary); UNKNOWN-FIXED h = 0 (experimental, no assumed gap); controls KNOWN-FIXED (no regime draw) and IID-REGIME (h = 1/2) |
| L (ROUTE) | null 1; positive bins {2, 3} (PROPOSED); sufficient ≥ 8 (clean) / 27 (graded) |
| Swap kernel | derangement for uniform and S1; resample for S2, labelled O-SEL-R / O-ROUTE-R (F5, accepted) |
| Time limit | 10 CPU-min per cell |

---

## 13. Thirteen admission answers (v2 retained, deltas marked)

| Q | Answer |
| --- | --- |
| Q1 | C3 bounded prerequisite: which W2′ conditions reward state-dependent retention, access, routing and upkeep allocation, and which remove that reward |
| Q2 | For each role X: does `full` strictly beat the X-denied class at equal per-phase reachable configurations (frozen K grid), under the declared semantics (S-DIRECT / S-MSG), across the bins, with the **proved** controls zero and the self-tests matched? |
| Q3 | Per-role REJECT-ABSENT / REJECT-NARROW / **REJECT-SIG**. REJECT-NARROW(ACC) is already known from the v1 replay (§7.3). A control violation invalidates the card. |
| Q4 | Repaired adaptive_select with {T_const, T_H}; cue_blind, static_access, static_route (v3 information set), fixed_upkeep, **cue_blind_upkeep**; selective prediction for graded ACC; evidence-reliability allocation for graded UPK (§5.4) |
| Q5 | SCARCITY_GAP_v1 §5 (replayed exactly; also fixes the ACC outcome, §7.3); Astra RESPONSE A and Consults #6 and #8; Phase III/III-B; Phase II |
| Q6 | ADMITted roles and their signature labels feed a separately approved emergence design, with §9 as the scaffold ledger |
| Q7 | REJECT-ABSENT parks role X. REJECT-NARROW redesigns the family. UNRESOLVED preserves the open cells. |
| Q8 | Analytic certificate: exact enumeration, branch-and-bound, exact Markov limits. No neural model, no organism. |
| Q9 | Organizational cognition |
| Q10 | §14 |
| Q11 | C3. Q-LEARN, ORIGIN, Q-CAUSE and C4 remain unsupported. |
| Q12 | O0/N1 paid persistence, in field form; no O3 bridge. Supplied: the world, the decision points, upkeep, decay (visible erasure = supplied access), consumers and channel. |
| Q13 | ADMIT(X) updates the C3 ceiling. REJECT-* adds scoped collapse entries. ADAPT feeds REDUCTION only, and only against {T_const, T_H}. ORIGIN is unchanged. |

---

## 14. Claim ceiling

**Under ADMIT(X), the strongest claim is:** "In W2′, under the declared semantics, at equal per-phase reachable
configurations and matched observations, actions, upkeep and memory protection, certified bounds show that the
task rewards role X over the declared X-denied class across the declared bins, and in each bin at least one
positive cell has at least one optimum exhibiting the response property P_X." This is **existential only** (F10).

For UPK, the role name is **adaptive maintenance allocation**. "Cue-attributed maintenance" requires the UPK_cue
sub-claim.

**NOT established:**
- acquisition;
- causal use in a developed system;
- necessity beyond the declared classes;
- UPK results under decoder semantics;
- graded UPK as cue-driven, or any clean UPK as cue-driven without UPK_cue;
- typicality or robustness of the signature across optima;
- ADAPT = 0 or ADAPT > 0 under the unknown-fixed regime as anything other than a measured result;
- C4;
- an O3 bridge;
- consciousness.

---

## 15. Flags

*v3 flags F1–F11 are retained below as the record of what Consult #8 ruled on. Their rulings are applied in D6–D9 and §0; where they conflict, the v4 text and the "v4 flags" section take precedence. The §0.1 table (C10) is likewise a historical v2→v3 record: its "stationary ADAPT = 0" proof is withdrawn by D1.*

- **F1. Mojibake (carried over).** Astra #6 says the mojibake did not drive its objections. The recommendation
  to send §§1–4 in ASCII before freezing stands.
- **F2. No protected controller or register.** Ruling (1) is applied: η is charged and pays upkeep. B_up = 3 is
  no longer the unpaid control in stage B (4 is). Nothing in v3 needed a protected element.
- **F3. Semantics choice.** S-DIRECT is adopted for every storage, upkeep and stage-B cell, and S-MSG for ROUTE.
  A decoder language for paid cells is **not** covered. If wanted, it needs its own proofs, because the UPK
  bounds may fail there.
- **F4. K_suff wording.** The Specialist wrote "minimum over phases of the maximum". I implemented Astra's
  "minimize the maximum reachable count across phases", i.e. min over optimal policies of max over phases. Please
  confirm.
- **F5. Swap kernel.** No derangement kernel preserves S2 = (2/3, 1/6, 1/6). Resampling is proposed for S2;
  it allows c′ = c, which dilutes O-SEL responses. The sweep is descriptive, so no decision depends on it.
- **F6. New hand counts.** These are the B_up = 2 phase counts (24, 20; 8, 12), UPK-Z4's K ≥ 18 and Z4′'s
  K ≥ 12, and K = 125 as ample. They are hand-derived and unverified by Astra.
- **F7. Graded UPK attribution.** 33/4096 shows that UPK in graded cells includes evidence-reliability
  allocation. Graded UPK is report-only, and cue-attributed UPK claims are clean-only. Astra may prefer a
  separate "reliability-UPK" contrast.
- **F8. ROUTE positive bins are unproved.** L ∈ {2, 3} positivity is not shown by hand. If the search certifies
  ROUTE = 0 in both, the result is REJECT-NARROW or REJECT-ABSENT, as designed.
- **F9. ADAPT has no response property.** ADAPT is value-only. If a signature is wanted (e.g. an η-lesion), it
  needs a definition.
- **F10. Signature gate.** The ADMIT requirement "ROBUST or PERMITTED in at least one CERT-POS cell per bin" is
  PROPOSED.
- **F11. The H = 3 tracker and η₀ = 2** are my specifications. Erasure resets to η₀, which for H = 3 is the
  neutral state.

### v4 flags (Consult #8 round)

- **G1. No protected controller or register.** None was added. The zero-ADAPT controls change the **world**
  (a known fixed map, or an i.i.d. regime), not the agent's memory. η stays charged and paid.
- **G2 (ACCEPTED, Consult #10).** KNOWN-FIXED regime 0 is the stage-A map with an unnecessary register. Regime 1
  is equivalent by relabelling the cue and its distribution. *Original flag:* **KNOWN-FIXED fixes regime 0 (map = c).** This makes stage B's known-fixed control coincide with a stage-A
  single-consumer v = 3/4 world plus an unused η. Regime 1 is symmetric under relabelling c → c+1, so one
  suffices. Confirm.
- **G3 (resolved by Consult #10, edit 3: unpaid cells are canonicalized to field vectors, §2.6).** *Original flag:* **The O-ACC unpaid sign proof** assumes unpaid cells write no meaningful durability marks (δ = 0 makes marks
  value-irrelevant, and the configuration is the field vector). If unpaid cells are instead modelled as B_up = 3
  with marks, the proof needs marks to be held constant (they are, since all fields are D). This is a hand
  argument and has not been reviewed by Astra.
- **G4 (ACCEPTED with Consult #10 edit 5).** Per-bin signature failure is legitimate narrowness, provided the
  failing bin is fully resolved (§7.2). *Original flag:* **REJECT-NARROW signature extension.** The per-bin case (some bin's positive cells are all certified
  NONE/SIG-UNDEFINED while another bin qualifies) was mapped to REJECT-NARROW. This is my extension; Consult #8
  asked only for the all-cells verdict (REJECT-SIG).
- **G5 (ACCEPTED, Consult #10).** A proven zero at degenerate K = 1 counts as zero for breadth, while remaining
  labelled DEGENERATE. The known ACC outcome appropriately prevents redundant discovery work. *Original flag:* **Known ACC outcome.** DEGENERATE K = 1 is treated as zero for the "bin entirely zero" test. The v1
  replay's static class equals static_access, and its codeword language equals unpaid S-DIRECT. The replay
  covered v ∈ {1/3, 1/2, 3/4}, r ∈ {1/2, 5/8, 3/4}; only the in-scope v ∈ {1/3, 3/4}, r ∈ {5/8, 3/4} values are
  cited.
- **G6. New hand proofs**, not yet reviewed by Astra: UPK-C0; the §5.3 UPK_cue attribution; K_suff = 16 (B_up = 2)
  and 26 (B_up = 1); and the §5.7 KNOWN-FIXED / IID proof.
- **G7. v3 md5.** v3 is untouched by this task. Its current md5 is fcb2f362…. I did not record v3's md5 when I
  wrote it, so I cannot confirm it is unchanged since then.
- **G8 (ACCEPTED WITH QUALIFICATION, Consult #10).** A timeout can leave UPK certified while UPK_cue remains
  UNRESOLVED. However, an unfinished required control still blocks the corresponding family-level ADMIT under the
  declared rules (§11, §7.2). *Original flag:* **Cost of cue_blind_upkeep.** Adding it means one extra class optimization per UPK cell, inside the
  existing 10-CPU-min cell budget. If that makes cells time out more often, UPK_cue becomes UNRESOLVED there,
  while UPK's own label is unaffected.
