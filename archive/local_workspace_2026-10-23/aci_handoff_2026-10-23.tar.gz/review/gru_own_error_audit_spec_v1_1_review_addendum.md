# CNA review addendum: spec v1.1 and the Research Lead's two checks

2026-10-21, ~6:50 PM ET. New file. It supplements `gru_own_error_audit_spec_v1_review.md` (sha f6b2db6f…), which stays unchanged. Reviewed: v1.1 sha256 `4661a8895ef495c28a1a41ff7405f029ff3c9f4451a12b1a1af9ccc701641ccf` (verified).

## 1. v1.1 delta

I diffed it against v1. The only changes are the header, the execution-order block, the §5 support note, the E31-9 pre-freeze disclosures, the §10 status and the change log. No rule, threshold, roster, split, falsifier or budget changed. Everything in my v1 review (A1, A2, M1–M3, m1–m5) applies unchanged to v1.1.

## 2. Check 1: is the Q1 proof sound?

**It is sound for lengths 1 and 2 and overstated for length 3.** I enumerated the prefix orbits under G = {id, ⊕0x55, ⊕0xAA, ⊕0xFF} restricted to k bits:

| prefix length k | G-orbits | consequence |
| --- | --- | --- |
| 1 | 1 (size 2) | every whole-orbit group contains both length-1 prefixes, so they are shared in every fold of every holdout |
| 2 | 1 (size 4) | likewise for all four length-2 prefixes: unavoidable |
| 3 | 2 (size 4) | avoidable: a holdout aligned with the two depth-3 orbits shares none |
| 4 | 4 | the declared groups A–D |

The v1 proof argues from F_X flipping reading 1. That establishes length 1, and length 2 follows by the same argument. It does not establish "any length below k₀": at length 3 there are two orbits. Concretely:
- A and C lie in one depth-3 orbit ({0,2,5,7} mod 8), and B and D lie in the other.
- The **AC|BD folds share no length-3 prefix**.
- AB|CD and AD|BC share all of them.

**Corrected statement:** under any whole-orbit holdout, prefixes of length 1–2 are necessarily shared. Length 3 is shared in 4 of the 6 declared folds and avoided in the 2 AC|BD folds. Lengths ≥ 4 are never shared.

This doesn't change my view that the sharing is harmless, because only stage-8 states are decoded. The proof text should still be corrected in the next version, and the AC|BD folds give a free descriptive sensitivity check.

## 3. Check 2: is the output-only control strong enough?

**No. A stronger control does not rescue T, because what T is meant to isolate is empty on this line.**

- The predictors are deterministic and the domain is finite, so e_S(h) = ‖f_S(h) − q(h)‖². That is an exact quadratic in (f_S, q), with no residual.
- **τ_conf (f, f(1−f)) is too weak.** It lacks q, so it cannot form e_S, and a state carrying some f_S and some q beats it with no error-specific content.
- **τ_fq ([f_S, q, f_S², q², f_S·q] per head) is the complete control.** It reproduces e_S exactly (R² = 1 up to ridge), so τ_state > τ_fq cannot be attained.
- The residual of e_S after the own output and the oracle is identically zero. Once the predictor's output is known, the target contains no error information left to "track".
- The oracle q is common to P and Q, so it cannot discriminate between predictors. All of T's predictor-specificity therefore comes from f_P, which the state carries by construction (f_P = readout_P(s_P)).

**Conclusion:** T, as defined, measures how much of the predictor's own output its state carries linearly. No output control can make it a test of error tracking beyond output. I recommend demoting T to descriptive and putting the identifiability question to Astra (#32): on deterministic predictors, is "tracks which predictor beyond its own output" identifiable at all? If Astra wants a non-trivial version, the candidates are:
- a predictive target: decode stage-8 error from an earlier-stage state, before the output is formed;
- a held-out-world error, under a declared distribution shift.

Both need new definitions, so they would go into a successor rather than a patch.

## 4. Package for Astra #32

For Astra #32, A1 and A2 should go as one identifiability question, alongside M1–M3 and the corrected Q1 statement above.
